package be.intecbrussel.alexander_oplossingen.ForestBook.entities.plant_entities.impl.enums;

/**
 * Created by Mrrobot on 29/05/2018 javabasics-workspace.
 */
public enum LeafType {

    NEEDLE,
    ROUND,
    HAND,
    HEART,
    SPEAR

}
